<?php

$connection = mysqli_connect("localhost",'id18307791_id18307791_makeurtrip','@JGs|\p3HrTmX%?K','id18307791_makeurtrip');

if(!$connection) {
	die("Unable to connect" . mysqli_error($connection));
}

?>